unit fp_epoxy;

interface

const
  {$ifdef linux}
  libepoxy = 'libepoxy';
  {$endif}

  {$ifdef windows}
  libepoxy = 'libepoxy-1.dll';
  {$endif}

type
  Tuint8_t = uint8;
  Puint8_t = ^Tuint8_t;
  PPuint8_t = ^Puint8_t;
  Tuint16_t = uint16;
  Puint16_t = ^Tuint16_t;
  PPuint16_t = ^Puint16_t;
  Tuint32_t = uint32;
  Puint32_t = ^Tuint32_t;
  PPuint32_t = ^Puint32_t;
  Tuint64_t = uint64;
  Puint64_t = ^Tuint64_t;
  PPuint64_t = ^Puint64_t;

  Tint8_t = int8;
  Pint8_t = ^Tint8_t;
  PPint8_t = ^Pint8_t;
  Tint16_t = int16;
  Pint16_t = ^Tint16_t;
  PPint16_t = ^Pint16_t;
  Tint32_t = int32;
  Pint32_t = ^Tint32_t;
  PPint32_t = ^Pint32_t;
  Tint64_t = int64;
  Pint64_t = ^Tint64_t;
  PPint64_t = ^Pint64_t;

  Tintptr_t = PtrInt;

  {$IFDEF FPC}
  {$PACKRECORDS C}
  {$ENDIF}

type
  TGLXextFuncPtr = Pointer;

  TEGLint = int32;
  PEGLint = ^TEGLint;

  TeglMustCastToProperFunctionPointerType = Pointer;

  // /usr/include/EGL/eglplatform.h
  TEGLNativePixmapType = Pointer;
  PEGLNativePixmapType = ^TEGLNativePixmapType;

  TEGLNativeWindowType = Pointer;
  PEGLNativeWindowType = ^TEGLNativeWindowType;

  TEGLNativeDisplayType = Pointer;
  PEGLNativeDisplayType = ^TEGLNativeDisplayType;

  // /usr/include/GL/glx.h
  P_GLXFBConfigRec = Pointer;
  P_GLXcontextRec = Pointer;


implementation

end.
