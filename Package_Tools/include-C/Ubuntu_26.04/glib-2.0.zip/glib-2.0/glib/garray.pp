
unit garray;
interface

{
  Automatically converted by H2Pas 1.0.0 from garray.h
  The following command line parameters were used:
    -p
    -T
    -d
    -c
    -e
    garray.h
}

    { Pointers to basic pascal types, inserted by h2pas conversion program.}
    Type
      PLongint  = ^Longint;
      PSmallInt = ^SmallInt;
      PByte     = ^Byte;
      PWord     = ^Word;
      PDWord    = ^DWord;
      PDouble   = ^Double;

    Type
    PGArray  = ^GArray;
    PGByteArray  = ^GByteArray;
    Pgchar  = ^gchar;
    Pgpointer  = ^gpointer;
    PGPtrArray  = ^GPtrArray;
    Pguint8  = ^guint8;
{$IFDEF FPC}
{$PACKRECORDS C}
{$ENDIF}


{ GLIB - Library of useful routines for C programming
 * Copyright (C) 1995-1997  Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
  }
{
 * Modified by the GLib Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GLib Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GLib at ftp://ftp.gtk.org/pub/gtk/.
  }
{$ifndef __G_ARRAY_H__}
{$define __G_ARRAY_H__}
{$if !defined (__GLIB_H_INSIDE__) && !defined (GLIB_COMPILATION)}
{$error "Only <glib.h> can be included directly."}
{$endif}
{$include <glib/gtypes.h>}
(* error 
typedef struct _GBytes          GBytes;
in declaration at line 38 *)
    type
      PGArray = ^TGArray;
      TGArray = record
          data : Pgchar;
          len : Tguint;
        end;

      PGByteArray = ^TGByteArray;
      TGByteArray = record
          data : Pguint8;
          len : Tguint;
        end;

      PGPtrArray = ^TGPtrArray;
      TGPtrArray = record
          pdata : Pgpointer;
          len : Tguint;
        end;

    { Resizable arrays. remove fills any cleared spot and shortens the
     * array, while preserving the order. remove_fast will distort the
     * order by moving the last element to the position of the removed.
      }
    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   

    function g_array_append_val(a,v : longint) : longint;    

    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   
    function g_array_prepend_val(a,v : longint) : longint;    

    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   
    function g_array_insert_val(a,i,v : longint) : longint;    

(* error 
#define g_array_index(a,t,i)      (((t*) (void *) (a)->data) [(i)])
in define line 69 *)
(* error 
GArray* g_array_new               (gboolean          zero_terminated,
(* error 
				   gboolean          clear_,
(* error 
				   guint             element_size);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_new_take          (gpointer          data,
(* error 
                                   gsize             len,
(* error 
                                   gboolean          clear,
(* error 
                                   gsize             element_size);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_new_take_zero_terminated (gpointer  data,
(* error 
                                          gboolean  clear,
(* error 
                                          gsize     element_size);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer g_array_steal            (GArray           *array,
(* error 
                                   gsize            *len);
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_sized_new         (gboolean          zero_terminated,
(* error 
				   gboolean          clear_,
(* error 
				   guint             element_size,
(* error 
				   guint             reserved_size);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_copy              (GArray           *array);
 in declarator_list *)
(* error 
gchar*  g_array_free              (GArray           *array,
(* error 
				   gboolean          free_segment);
 in declarator_list *)
 in declarator_list *)
(* error 
GArray *g_array_ref               (GArray           *array);
 in declarator_list *)
(* error 
void    g_array_unref             (GArray           *array);
in declaration at line 100 *)
(* error 
guint   g_array_get_element_size  (GArray           *array);
 in declarator_list *)
(* error 
GArray* g_array_append_vals       (GArray           *array,
(* error 
				   gconstpointer     data,
(* error 
				   guint             len);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_prepend_vals      (GArray           *array,
(* error 
				   gconstpointer     data,
(* error 
				   guint             len);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_insert_vals       (GArray           *array,
(* error 
				   guint             index_,
(* error 
				   gconstpointer     data,
(* error 
				   guint             len);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_set_size          (GArray           *array,
(* error 
				   guint             length);
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_remove_index      (GArray           *array,
(* error 
				   guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_remove_index_fast (GArray           *array,
(* error 
				   guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
GArray* g_array_remove_range      (GArray           *array,
(* error 
				   guint             index_,
(* error 
				   guint             length);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
void    g_array_sort              (GArray           *array,
in declaration at line 131 *)
(* error 
void    g_array_sort_with_data    (GArray           *array,
in declaration at line 135 *)
(* error 
gboolean g_array_binary_search    (GArray           *array,
(* error 
                                   gconstpointer     target,
(* error 
                                   GCompareFunc      compare_func,
(* error 
                                   guint            *out_match_index);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
void    g_array_set_clear_func    (GArray           *array,
in declaration at line 143 *)
    { Resizable pointer array.  This interface is much less complicated
     * than the above.  Add appends a pointer.  Remove fills any cleared 
     * spot and shortens the array. remove_fast will again distort order.  
      }
(* error 
#define    g_ptr_array_index(array,index_) ((array)->pdata)[index_]
in define line 149 *)
(* error 
GPtrArray* g_ptr_array_new                (void);
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_with_free_func (GDestroyNotify    element_free_func);
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_take           (gpointer         *data,
(* error 
                                           gsize             len,
(* error 
                                           GDestroyNotify    element_free_func);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_from_array     (gpointer         *data,
(* error 
                                           gsize             len,
(* error 
                                           GCopyFunc         copy_func,
(* error 
                                           gpointer          copy_func_user_data,
(* error 
                                           GDestroyNotify    element_free_func);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer*   g_ptr_array_steal              (GPtrArray        *array,
(* error 
                                            gsize            *len);
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray *g_ptr_array_copy               (GPtrArray        *array,
(* error 
                                           GCopyFunc         func,
(* error 
                                           gpointer          user_data);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_sized_new          (guint             reserved_size);
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_full           (guint             reserved_size,
(* error 
					   GDestroyNotify    element_free_func);
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_null_terminated (guint          reserved_size,
(* error 
                                            GDestroyNotify element_free_func,
(* error 
                                            gboolean       null_terminated);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_take_null_terminated  (gpointer       *data,
(* error 
                                                  GDestroyNotify  element_free_func);
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_new_from_null_terminated_array (gpointer       *data,
(* error 
                                                       GCopyFunc       copy_func,
(* error 
                                                       gpointer        copy_func_user_data,
(* error 
                                                       GDestroyNotify  element_free_func);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer*  g_ptr_array_free               (GPtrArray        *array,
(* error 
					   gboolean          free_segment);
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray* g_ptr_array_ref                (GPtrArray        *array);
 in declarator_list *)
(* error 
void       g_ptr_array_unref              (GPtrArray        *array);
in declaration at line 194 *)
(* error 
void       g_ptr_array_set_free_func      (GPtrArray        *array,
in declaration at line 197 *)
(* error 
void       g_ptr_array_set_size           (GPtrArray        *array,
in declaration at line 200 *)
(* error 
gpointer   g_ptr_array_remove_index       (GPtrArray        *array,
(* error 
					   guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer   g_ptr_array_remove_index_fast  (GPtrArray        *array,
(* error 
					   guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer   g_ptr_array_steal_index        (GPtrArray        *array,
(* error 
                                           guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
gpointer   g_ptr_array_steal_index_fast   (GPtrArray        *array,
(* error 
                                           guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
gboolean   g_ptr_array_remove             (GPtrArray        *array,
(* error 
					   gpointer          data);
 in declarator_list *)
 in declarator_list *)
(* error 
gboolean   g_ptr_array_remove_fast        (GPtrArray        *array,
(* error 
					   gpointer          data);
 in declarator_list *)
 in declarator_list *)
(* error 
GPtrArray *g_ptr_array_remove_range       (GPtrArray        *array,
(* error 
					   guint             index_,
(* error 
					   guint             length);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
void       g_ptr_array_add                (GPtrArray        *array,
in declaration at line 225 *)
(* error 
void g_ptr_array_extend                   (GPtrArray        *array_to_extend,
in declaration at line 230 *)
(* error 
void g_ptr_array_extend_and_steal         (GPtrArray        *array_to_extend,
in declaration at line 233 *)
(* error 
void       g_ptr_array_insert             (GPtrArray        *array,
in declaration at line 237 *)
(* error 
void       g_ptr_array_sort               (GPtrArray        *array,
in declaration at line 240 *)
(* error 
void       g_ptr_array_sort_with_data     (GPtrArray        *array,
in declaration at line 244 *)
(* error 
void       g_ptr_array_sort_values        (GPtrArray        *array,
in declaration at line 247 *)
(* error 
void       g_ptr_array_sort_values_with_data (GPtrArray        *array,
in declaration at line 251 *)
(* error 
void       g_ptr_array_foreach            (GPtrArray        *array,
in declaration at line 255 *)
(* error 
gboolean   g_ptr_array_find               (GPtrArray        *haystack,
(* error 
                                           gconstpointer     needle,
(* error 
                                           guint            *index_);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
gboolean   g_ptr_array_find_with_equal_func (GPtrArray     *haystack,
(* error 
                                             gconstpointer  needle,
(* error 
                                             GEqualFunc     equal_func,
(* error 
                                             guint         *index_);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
gboolean   g_ptr_array_is_null_terminated (GPtrArray *array);
 in declarator_list *)
    { Byte arrays, an array of guint8.  Implemented as a GArray,
     * but type-safe.
      }
(* error 
GByteArray* g_byte_array_new               (void);
 in declarator_list *)
(* error 
GByteArray* g_byte_array_new_take          (guint8           *data,
(* error 
                                            gsize             len);
 in declarator_list *)
 in declarator_list *)
(* error 
guint8*     g_byte_array_steal             (GByteArray       *array,
(* error 
                                            gsize            *len);
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_sized_new         (guint             reserved_size);
 in declarator_list *)
(* error 
guint8*     g_byte_array_free              (GByteArray       *array,
(* error 
					    gboolean          free_segment);
 in declarator_list *)
 in declarator_list *)
(* error 
GBytes*     g_byte_array_free_to_bytes     (GByteArray       *array);
 in declarator_list *)
(* error 
GByteArray *g_byte_array_ref               (GByteArray       *array);
 in declarator_list *)
(* error 
void        g_byte_array_unref             (GByteArray       *array);
in declaration at line 291 *)
(* error 
GByteArray* g_byte_array_append            (GByteArray       *array,
(* error 
					    const guint8     *data,
(* error 
					    guint             len);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_prepend           (GByteArray       *array,
(* error 
					    const guint8     *data,
(* error 
					    guint             len);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_set_size          (GByteArray       *array,
(* error 
					    guint             length);
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_remove_index      (GByteArray       *array,
(* error 
					    guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_remove_index_fast (GByteArray       *array,
(* error 
					    guint             index_);
 in declarator_list *)
 in declarator_list *)
(* error 
GByteArray* g_byte_array_remove_range      (GByteArray       *array,
(* error 
					    guint             index_,
(* error 
					    guint             length);
 in declarator_list *)
 in declarator_list *)
 in declarator_list *)
(* error 
void        g_byte_array_sort              (GByteArray       *array,
in declaration at line 315 *)
(* error 
void        g_byte_array_sort_with_data    (GByteArray       *array,
in declaration at line 319 *)
{$endif}
    { __G_ARRAY_H__  }
(* error 
#endif /* __G_ARRAY_H__ */

implementation

    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   
    function g_array_append_val(a,v : longint) : longint;
    begin
      g_array_append_val:=g_array_append_vals(a,@(v),1);
    end;

    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   
    function g_array_prepend_val(a,v : longint) : longint;
    begin
      g_array_prepend_val:=g_array_prepend_vals(a,@(v),1);
    end;

    { was #define dname(params) para_def_expr }
    { argument types are unknown }
    { return type might be wrong }   
    function g_array_insert_val(a,i,v : longint) : longint;
    begin
      g_array_insert_val:=g_array_insert_vals(a,i,@(v),1);
    end;


end.
